import { Base } from '../templates/Base';

const Index = () => <Base />;

export default Index;
