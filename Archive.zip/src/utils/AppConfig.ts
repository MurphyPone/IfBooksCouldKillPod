export const AppConfig = {
  site_name: 'IfBooksCouldKill',
  title: 'If Books Could Kill',
  description: 'The airport bestsellers that captured our hearts and ruined our minds',
  locale: 'en',
};
